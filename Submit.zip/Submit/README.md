# VAMR-mini project

## To run the code

run main in matlab command line:

```matlab
main
```

## The specifications of the machine and Matlab version

| Maximum number of used threads | 6               |
| ------------------------------ | --------------- |
| **CPU frequency**              | I7-8Gen 2.21GHz |
| **RAM**                        | 8G              |
| **Matlab version**             | 2017a           |

## Video address on Youtube

https://www.youtube.com/playlist?list=PLFy5hlHdq7W6l5G42UbXeH3ER4VQeBkfE
